package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Category;
import com.example.demo.Entity.Product;
import com.example.demo.Repository.ProductRepo;

@Service
public class ProductService {
	@Autowired
    private ProductRepo productRepo;

    @Autowired
    private CategoryService categoryService;
// Get List of Product (use of pagination)
    public Page<Product> getAllProducts(Pageable pageable) {
        return productRepo.findAll(pageable);
    }
// Save or add the product 
    public Product createProduct(Product product, Long categoryId) {
        Category category = categoryService.getCategoryById(categoryId);
        product.setCategory(category);
        return productRepo.save(product);
    }
// Get product details by its id
    public Product getProductById(Long id) {
        return productRepo.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
    }
// modify product details using its id
    public Product updateProduct(Long id, Product productDetails) {
        Product existing = getProductById(id);
        existing.setName(productDetails.getName());
        existing.setPrice(productDetails.getPrice());
        return productRepo.save(existing);
    }
// Delete spcific Product
    public void deleteProduct(Long id) {
    	productRepo.deleteById(id);
    }
}
