package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Category;
import com.example.demo.Repository.CategoryRepo;

@Service
public class CategoryService {
	@Autowired
    private CategoryRepo categoryRepo;

	// Get List of categories
    public List<Category> getAllCategories() {
        return categoryRepo.findAll();
    }
  // To save the category details
    public Category createCategory(Category category) {
        return categoryRepo.save(category);
    }
// To search the category by using its id 
    public Category getCategoryById(Long id) {
        return categoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
    }
// modify the category details using id attribute
    public Category updateCategory(Long id, Category updatedCategory) {
        Category category = categoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        category.setName(updatedCategory.getName());
        return categoryRepo.save(category);
    }
// delete the category by serching using its id
    public void deleteCategory(Long id) {
        categoryRepo.deleteById(id);
    }
}
