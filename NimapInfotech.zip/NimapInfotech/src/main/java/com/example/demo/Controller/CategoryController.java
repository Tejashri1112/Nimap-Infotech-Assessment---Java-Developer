package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Category;
import com.example.demo.Service.CategoryService;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
	  @Autowired
	    private CategoryService categoryService;

	    
// To Add The category Details
	    @PostMapping
	    public Category createCategory(@RequestBody Category category) {
	        return categoryService.createCategory(category);
	    }
	    
// To Get List Of All Categories	    
	    @GetMapping
	    public List<Category> getAllCategories() {
	        return categoryService.getAllCategories();
	    }
// To Get Category By Specific Id	    
	    @GetMapping("/{id}")
	    public Category getCategoryById(@PathVariable Long id) {
	        return categoryService.getCategoryById(id);
	    }
// To Update or modify the Category details using id
	    @PutMapping("/{id}")
	    public Category updateCategory(@PathVariable Long id, @RequestBody Category updatedCategory) {
	        return categoryService.updateCategory(id, updatedCategory);
	    }
// To delete The Specific Category record finding by its id 
	    @DeleteMapping("/{id}")
	    public String deleteCategory(@PathVariable Long id) {
	        categoryService.deleteCategory(id);
	        return "Category deleted successfully";
	    }
}
